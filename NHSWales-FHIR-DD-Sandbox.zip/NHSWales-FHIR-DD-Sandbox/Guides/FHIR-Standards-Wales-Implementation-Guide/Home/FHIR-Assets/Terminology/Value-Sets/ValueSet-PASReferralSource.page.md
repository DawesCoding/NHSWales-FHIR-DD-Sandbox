<div class="warning"><span class="ImplementWarn"></span></div>

## {{page-title}}

This Value Set is based on UKCore Source Of Service Request with additional codes from PAS Referral Source Code System.  The PAS Referral Source Code System is owned and managed by Digital Health and Care Wales WPAS. These are not a data standard and this snapshot is for example use only.

{{render:https://fhir.nhs.wales/ValueSet/PASReferralSource, text:PASReferralSource}}

